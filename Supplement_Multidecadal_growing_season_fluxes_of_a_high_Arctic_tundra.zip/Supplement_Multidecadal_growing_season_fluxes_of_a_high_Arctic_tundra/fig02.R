# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# fig02.png is an output from QGIS. The figure combines the approximate study locations with a vegetation map of Zackenberg Valley. 
# The figure also shows the two study areas, Rylekærene and the Valley floor, and an overview of some of the locations featured in the study
# Data sources: HyMap hyperspectral imaging campaign (7 August 2000), ESA Copernicus Sentinel-2 (16 July 2019), and © BING Maps 2021