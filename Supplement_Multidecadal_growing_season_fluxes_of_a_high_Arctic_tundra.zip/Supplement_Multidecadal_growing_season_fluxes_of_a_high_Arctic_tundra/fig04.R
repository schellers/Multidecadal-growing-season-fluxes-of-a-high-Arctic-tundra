# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Data -------------------------------------------------------------------

gully_flux <- read_csv("data/gully_surface_fluxes.csv")

# Data preparation --------------------------------------------------------

i <- c(2:8, 11:13, 16:23)

gully_flux[,i] <- apply(gully_flux[,i], 2, function(x) as.numeric(as.character(x))) # vector containing index numbers for columns in the data frame that require conversion from the character to number format


gully_flux2 <- gully_flux %>% # create a new data frame based on the imported data
          mutate(Location = str_replace(Location, "Edge", "Eroded")) %>% # rename
          mutate(Location = str_replace(Location, "Surface", "Grassland/barren")) 

gully_fluxes <- gully_flux2 %>%
          group_by(name) %>%
          mutate(plotmean = mean(CH4_Flux_m)) %>% # first average on each plot...
          ungroup() %>%
          group_by(Location) %>%
          mutate(classmeans = mean(plotmean)) %>% # ...then average the plot means as class means
          mutate(se = sd(plotmean, na.rm = TRUE)/sqrt(sum(!is.na(plotmean)))) # calculate se


# The results are added - along with a few annotations - to an overview photo of the site to create fig04 as it appears in the manuscript


# Tidy up environment
rm(list = ls(all.names = TRUE)) 