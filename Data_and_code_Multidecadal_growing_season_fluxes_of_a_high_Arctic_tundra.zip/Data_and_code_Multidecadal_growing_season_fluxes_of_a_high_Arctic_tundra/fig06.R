# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Data -------------------------------------------------------------------

future_flux <- read_excel("data/Erosion along the river.xlsx", sheet = "Figure_R")

# Data preparation -------------------------------------------------------

future_flux$period <- factor(future_flux$period, levels = c("2008 - 2015", "2041 - 2060", "2081 - 2100", "2081 - 2100 (magnified)"), 
                             labels = c("2008\u20132015", "2041\u20132060", "2081\u20132100", "2081\u20132100 (magnified)")) # create en dashes 

part_2008_2015 <- future_flux %>% filter(period == "2008\u20132015")
part_2041_2060 <- future_flux %>% filter(period == "2041\u20132060")
part_2081_2100 <- future_flux %>% filter(period == "2081\u20132100")
part_2081_2100_magnified <- future_flux %>% filter(period == "2081\u20132100 (magnified)")

# Figure 6 ----------------------------------------------------------------

plot_2008_2015 <- ggplot(part_2008_2015)  +
          geom_bar(stat = "identity", aes(x = group, y = flux, fill = order), width = 0.3, lwd = 0.25, position = position_stack(reverse = TRUE)) +
          theme_pubr(base_size = 10, base_family = "") +
          facet_wrap(~period, scales = "free") +
          labs(x = NULL, y = expression(Mean~valley~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})))+
          scale_x_discrete(labels = c("No RCP8.5 &\nno erosion")) +
          scale_y_continuous(limits = c(0,0.46)) +
          scale_fill_manual(values = c("#A5170E", "#196580", "#4eb265", "#f6c141", "#882e72"), labels = c("Valley", "Fen", "Grassland", "Heath", "Salix" )) +
          theme(legend.title = element_blank(),
                legend.margin = margin(2, 2, 2, 2),
                legend.text = element_text(size = 9),
                strip.background = element_rect(color = NA, fill = "grey80"), 
                strip.text.x = element_text(size = 10),
                legend.background = element_blank(),
                legend.justification = c(0, 1), legend.position = c(0, 1)) +
          guides(fill = guide_legend(ncol = 2))


plot_2041_2060 <- ggplot(part_2041_2060)  +
          geom_bar(stat = "identity", aes(x = group, y = flux, fill = order), width = 0.6, lwd = 0.25, position = position_stack(reverse = TRUE)) +
          theme_pubr(base_size = 10, base_family = "") +
          facet_wrap(~period, scales = "free") +
          labs(x = NULL, y = expression(Mean~valley~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})))+
          scale_x_discrete(labels = c("RCP8.5 &\n25 m erosion ", " RCP8.5 &\n100 m erosion")) +
          scale_y_continuous(limits = c(0, 0.46), labels = NULL) +
          scale_fill_manual(values = c("#A5170E", "#196580", "#4eb265", "#f6c141", "#882e72"), labels = c("Valley", "Fen", "Grassland", "Heath", "Salix" )) +
          theme(plot.title = element_text(size = 7, hjust = 0.5),
                axis.title.y = element_blank(),         
                strip.text.x = element_text(size = 10),
                strip.background = element_rect(color = NA, fill = "grey80"),
                legend.position = "none")


plot_2081_2100 <- ggplot(part_2081_2100)  +
          geom_bar(stat = "identity", aes(x = group, y = flux, fill = order), width = 0.6, lwd = 0.25, position = position_stack(reverse = TRUE)) +
          theme_pubr(base_size = 10, base_family = "") +
          facet_wrap(~period, scales= "free") +
          labs(x = NULL, y = expression(Mean~valley~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})))+
          scale_x_discrete(labels = c("RCP8.5 &\n25 m erosion ", " RCP8.5 &\n100 m erosion")) +
          scale_y_continuous(limits = c(0, 0.46), labels = NULL) +
          scale_fill_manual(values = c("#A5170E", "#196580", "#4eb265", "#f6c141", "#882e72"), labels = c("Valley", "Fen", "Grassland", "Heath", "Salix" )) +
          theme(axis.title.y = element_blank(),         
                strip.text.x = element_text(size = 10),
                strip.background = element_rect(color = NA, fill = "grey80"), 
                legend.justification = c(0, 1), legend.position = "none") +
          guides(fill = guide_legend(ncol = 2))

plot_2081_2100_magnified <- ggplot(part_2081_2100_magnified)  +
          geom_bar(stat = "identity", aes(x = group, y = flux, fill = order), width = 0.6, lwd = 0.25, position = position_stack(reverse = TRUE)) +
          facet_wrap(~period, scales = "free") +
          theme_pubr(base_size = 10, base_family = "") +
          labs(x = NULL, y = expression(Mean~valley~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})))+
          coord_cartesian(ylim = c(0.4, 0.46), clip = "on") +
          scale_x_discrete(labels = c("RCP8.5 &\n25 m erosion ", " RCP8.5 &\n100 m erosion")) +
          scale_y_continuous(position = "right") +
          scale_fill_manual(values = c("#A5170E", "#196580", "#4eb265", "#f6c141", "#882e72" ), labels = c("Valley", "Fen", "Grassland", "Heath", "Salix" )) +
          theme(axis.title.y = element_blank(),         
                panel.background = element_rect(fill = "#CAE0AB"),
                strip.text.x = element_text(size = 10),
                strip.background = element_rect(color = NA, fill = "grey80"), 
                legend.position = "none")

plot_future <- plot_grid(plot_2008_2015, plot_2041_2060, plot_2081_2100, plot_2081_2100_magnified, ncol = 4, nrow = 1, rel_widths = c(0.286,0.233,0.233, 0.267)) # odd-looking numbers here, had to compensate for differences when there are axes in the left and right panel

ggsave(plot_future,
       filename = "figures/fig06.png", # a wedge is added to the figure in a photo editing program
       bg = "white",
       units = "in", # kept in inches, to avoid messy look
       width = 9, 
       height = 5, 
       pointsize = 8, 
       dpi = 300, 
       device = "png")

# Tidy up environment
rm(list = ls(all.names = TRUE)) 