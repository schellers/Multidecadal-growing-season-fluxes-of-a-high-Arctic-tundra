# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries --------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Color palette ----------------------------------------------------------

palette_ac <- c("#AE76A3", "#196580", "#7BAFDE", "#90C987", "#F4E455", "#F1932D", "#DC050C")

# Data -------------------------------------------------------------------

ac <- read_excel("data/AC_fluxes_2006-2019.xlsx", guess_max = 17000) # excel table consisting of all chamber time series from 2006-2019


# Data preparation --------------------------------------------------------

ac_ja_1to6 <- ac %>%
          mutate(Datetime = ymd_hms(Datetime)) %>%
          mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
          mutate(hours = as.numeric(format(Datetime, "%H"))) %>% # conversion of text format to months/dates/hours
          filter(between(monthday, 701, 831)) %>% # july and august
          mutate(year = year(Datetime)) %>% # extract year from time column 
          mutate(n_obs = rowSums(!is.na(.[,2:7]))) %>% # sum number of observations per time interval
          group_by(year) %>%
          summarize(mean_1 = mean(CH1, na.rm = TRUE), # mean of all non-NA measurements at Chamber 1 and so on
                    mean_2 = mean(CH2, na.rm = TRUE),
                    mean_3 = mean(CH3, na.rm = TRUE),
                    mean_4 = mean(CH4, na.rm = TRUE),
                    mean_5 = mean(CH5, na.rm = TRUE),
                    mean_6 = mean(CH6, na.rm = TRUE),
                    mean_1to6 = mean(c(mean_1, mean_2, mean_3, mean_4, mean_5, mean_6)), # mean of the six chamber means
                    SE_1 = sd(CH1, na.rm = TRUE)/sqrt(sum(!is.na(CH1))), # standard errors (se) of all non-NA measurements at Chamber 1 and so on
                    SE_2 = sd(CH2, na.rm = TRUE)/sqrt(sum(!is.na(CH2))),
                    SE_3 = sd(CH3, na.rm = TRUE)/sqrt(sum(!is.na(CH3))),
                    SE_4 = sd(CH4, na.rm = TRUE)/sqrt(sum(!is.na(CH4))),
                    SE_5 = sd(CH5, na.rm = TRUE)/sqrt(sum(!is.na(CH5))),
                    SE_6 = sd(CH6, na.rm = TRUE)/sqrt(sum(!is.na(CH6))),
                    SE_1to6 = sd(c(mean_1, mean_2, mean_3, mean_4, mean_5, mean_6), na.rm = TRUE)/sqrt(6), # standard error on the mean measurements
                    count_1 = sum(!is.na(CH1)), # count number of non-NA measurements
                    count_2 = sum(!is.na(CH2)),
                    count_3 = sum(!is.na(CH3)),
                    count_4 = sum(!is.na(CH4)),
                    count_5 = sum(!is.na(CH5)),
                    count_6 = sum(!is.na(CH6))) %>%
          gather(key, value = mgm2h, -year) %>%  separate(key, into = c("stat", "chamber"), sep = "_") %>% # reorder to narrow table, separate into stat column (mean, se, and count) and chamber column @ underscore
          spread(stat, mgm2h) # separate stat column into mean, se, and count columns

ac_ja_1to6_all_time <- ac %>% # all time mean and se
          mutate(Datetime = ymd_hms(Datetime)) %>%
          mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
          mutate(hours = as.numeric(format(Datetime, "%H"))) %>% # conversion of text format to months/dates/hours
          filter(between(monthday, 701, 831)) %>% # dates 07-01 to 08-31
          select(-c(8:11)) %>%
          mutate(year = year(Datetime)) %>%
          gather(chamber, value = mgm2h, -year, -monthday, -hours, -Datetime) %>%  summarize(mean_1to6_all_time = mean(mgm2h, na.rm = TRUE), SE_1to6 = sd(mgm2h, na.rm = TRUE)/sqrt(length(which(!is.na(mgm2h)))))

ac_ja_7to10_all_time <- ac %>% # all time mean and SE
          mutate(Datetime = ymd_hms(Datetime)) %>%
          mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
          mutate(hours = as.numeric(format(Datetime, "%H"))) %>% # conversion of text format to months/dates/hours
          filter(between(monthday, 701, 831)) %>% # dates 07-01 to 08-31
          select(-c(2:7)) %>%
          mutate(year = year(Datetime)) %>%
          gather(chamber, value = mgm2h, -year, -monthday, -hours, -Datetime) %>%  summarize(mean_1to6_all_time = mean(mgm2h, na.rm =TRUE), SE_1to6 = sd(mgm2h, na.rm = TRUE)/sqrt(length(which(!is.na(mgm2h)))))


ac_ja_1to6_all <- subset(ac_ja_1to6, chamber == "1to6") %>% # only "1to6"
          mutate(mean = replace(mean, year == 2006, 2.266324498*0.912346509 )) %>% # make a new data frame with only mean measurements from chamber 1-6, and correction for 2006's 4 chamber setup. 0.912346509 should be used as scale factor for mean for 4 chambers (2.26 mg h-1 m-2)
          mutate(anomaly = mean - mean(mean)) # make a new column with anomalies

ac_ja_1to6_indi <- subset(ac_ja_1to6, chamber != "1to6") %>% # make a new dataframe with measurements from each of the chambers 1-6, omit "1to6"
          mutate(anomaly = mean - mean(ac_ja_1to6_all$mean)) # make a new column with anomalies

ac_1to6 <- ac_ja_1to6_indi %>%
          group_by(chamber) %>%
          mutate(year =  year + runif(1, -0.15, 0.15)) %>% # add a random offset to avoid overplotting
          ungroup()


# Figure 3 ----------------------------------------------------------------

plot_ac_1to6 <- ggplot(ac_1to6, aes(x = year)) + # default data is data from all six chambers, separated
          geom_line(data = ac_ja_1to6_all, aes(x = year, y = mean, color = "Mean 1-6"), alpha = 1) + # plot a mean line
          geom_point(data = ac_ja_1to6_all, aes(x = year, y = mean, color = "Mean 1-6"), alpha = 1) + # plot points
          geom_errorbar(data = ac_ja_1to6_all, aes(ymin = mean - SE, ymax = mean + SE, color = "Mean 1-6"), width = 0.1,  alpha = 1) + # plot error bars
          geom_errorbar(aes(ymin = mean - SE, ymax = mean + SE, color = chamber), width = 0.2, alpha = 1) + # plot the next set of error bars
          geom_point(aes(y = mean, color = chamber), alpha = 1) +
          theme_pubr(base_size = 10, base_family = "") +
          theme(legend.title = element_blank(),
                legend.justification = c(1, 1), 
                legend.position = c(1, 1),
                legend.spacing.x = unit(0.2, "cm"),
                legend.key.size =  unit(0.25, "cm"),
                axis.ticks = element_line(size = 0.25),
                legend.margin = margin(2, 2, 2, 2)) +
          scale_x_continuous(name = "Year", breaks = seq(2006, 2019, by = 1)) +
          scale_y_continuous(expression(Measured~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})),
                             breaks = seq(-1, 6.5, 0.5), limits = c(0, 6.5)) + # mean from all inner chambers, 2006-2019
          scale_color_manual(values = palette_ac, labels = c("Chamber 1 (n = 289 to 1447)", "Chamber 2 (n = 304 to 1471)", "Chamber 3 (n = 243 to 1471)",
                                                             "Chamber 4 (n = 335 to 1329)", "Chamber 5 (n = 326 to 1477)", "Chamber 6 (n = 299 to 1286)", "Chamber 1 to 6 mean* (n = 4 to 6)")) # n differs from year to year, this shows the range over the period

plot_ac_1to6


# Chambers 7 to 10 (2012-2019) --------------------------------------------

ac_ja_7to10 <- ac %>%
        mutate(Datetime = ymd_hms(Datetime)) %>%
        mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
        mutate(hours = as.numeric(format(Datetime, "%H"))) %>%
        filter(between(monthday, 701, 831)) %>% # dates 07-01 to 08-31
        mutate(year = year(Datetime)) %>%
        filter(between(year, 2012, 2019)) %>% # years 2012 to 2019
        mutate(n_obs = rowSums(!is.na(.[,8:11]))) %>% # sum number of observations per time interval
        group_by(year) %>%
        summarize(mean_7 = mean(CH7, na.rm = TRUE),
                  mean_8 = mean(CH8, na.rm = TRUE),
                  mean_9 = mean(CH9, na.rm = TRUE),
                  mean_10 = mean(CH10, na.rm = TRUE),
                  mean_7to10 = mean(c(mean_7, mean_8, mean_9, mean_10)),
                  SE_7 = sd(CH7, na.rm = TRUE)/sqrt(sum(!is.na(CH7))),
                  SE_8 = sd(CH8, na.rm = TRUE)/sqrt(sum(!is.na(CH8))),
                  SE_9 = sd(CH9, na.rm = TRUE)/sqrt(sum(!is.na(CH9))),
                  SE_10 = sd(CH10, na.rm = TRUE)/sqrt(sum(!is.na(CH10))),
                  SE_7to10 = sd(c(mean_7, mean_8, mean_9, mean_10), na.rm = TRUE)/sqrt(4),
                  count_7 = sum(!is.na(CH7)),
                  count_8 = sum(!is.na(CH8)),
                  count_9 = sum(!is.na(CH9)),
                  count_10 = sum(!is.na(CH10))) %>%
        gather(key, value = mgm2h, -year) %>%  separate(key, into = c("stat", "chamber"), sep = "_") %>%
        spread(stat, mgm2h)

ac_ja_7to10_all <- subset(ac_ja_7to10, chamber == "7to10") %>% 
        mutate(anomaly = mean - mean(mean))
ac_ja_7to10_indi <- subset(ac_ja_7to10, chamber != "7to10") %>%
        mutate(anomaly = mean - mean(ac_ja_7to10_all$mean))

ac_7to10 <- ac_ja_7to10_all %>%
        group_by(chamber) %>%
        mutate(year =  year + runif(1, -0.15, 0.15)) %>%
        ungroup()


library(mcr)

deming_reg <- read_excel("data/workbook.xlsx", sheet = 7)

reg2 <-  mcreg(deming_reg$ac, deming_reg$fen, error.ratio = 0.44, alpha = 0.05, method.reg = "Deming", method.ci = "jackknife") # error ratio calculated in new_valley_flux.xlsx sheet

MCResult.plot(reg2, equal.axis = FALSE, x.lab = "AC", y.lab = "Fen", points.col = "red", points.pch = 19, ci.area = TRUE, identity = FALSE, ci.area.col = "#0000FF50", sub = "", add.grid = FALSE, points.cex = 1)
abline(reg2@para[1:2], col = "blue")
points(x,(intercept+iSE)+(slope+sSE)*x,typ="l",col="green")
points(x,(intercept-iSE)+(slope-sSE)*x,typ="l",col="red")

intercept <- reg2@para[1,1] # regression parameters
iLCI <- reg2@para[1,3]
iUCI <- reg2@para[1,4]
iSE <- reg2@para[1,2]
slope <- reg2@para[2,1]
sLCI <-reg2@para[2,3]
sUCI <-reg2@para[2,4]
sSE <- reg2@para[2,2]


x <- seq(0.1, 5, by = 0.2) # generate x values for plot 

plot(deming_reg$ac, deming_reg$fen)
abline(reg2@para[1:2], col = "blue")
points(x,(intercept + iSE) + (slope + sSE) *x, typ = "l", col = "green")
points(x,(intercept - iSE) + (slope - sSE) * x, typ = "l",col = "red") # another regression plot

ac_years <- c(2.07,3.41,0.95,1.46,1.03,0.26,0.66,0.41,0.41,1.28,2.17,1.87,0.92, 1.44) # mean AC 1-6 flux

fen_years <- c(2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019)

fen_years_mean <- intercept + slope * ac_years # calculated fluxes in fen areas
fen_years_se <- (iSE + sSE) * ac_years # estimated SE

fenflux <- as.data.frame(cbind(fen_years, fen_years_mean, fen_years_se))

write_csv(fenflux, "data/fen_model_output.csv")

ggplot(fenflux, aes(fen_years, fen_years_mean)) +
        geom_line() +
        geom_errorbar(aes(ymin = fen_years_mean - fen_years_se, ymax = fen_years_mean + fen_years_se))

# Landscape flux
library(plyr)

vegetation_fluxes <- read_excel("data/vegetation_class_fluxes.xlsx") # simplified results based on Tagesson/Christensen/J�rgensen

vegetation_fluxes$type <- factor(vegetation_fluxes$type, levels = c("fen", "fen_fringe", "grassland", "fell_barren", "heath", "salix", "Rylek�rene", "Valley floor"))

vegetation_fluxes2 <- plyr::ddply(vegetation_fluxes,.(year, area),transform, # make errorbars fit in the plot, the errorbars for the negative fluxes in rylek�rene are omitted, they are very small
                                  ybegin = ifelse(flux_scaled > 0, cumsum(flux_scaled_p) - se_scaled_p, cumsum(flux_scaled_n) - se_scaled_n) - correction, 
                                  yend = ifelse(flux_scaled > 0, cumsum(flux_scaled_p) + se_scaled_p, cumsum(flux_scaled_n) + se_scaled_n)  - correction)   

fig06 <-ggplot(vegetation_fluxes2, aes(x = year, y = flux_scaled)) + 
        geom_bar(data = vegetation_fluxes2 %>% subset(type %in% c("fen","fen_fringe", "grassland", "fell_barren", "heath", "salix")), stat = "identity", aes(fill = type), alpha = 0.7 , size =.5, width = 0.9) +
        geom_linerange(data = vegetation_fluxes2 %>% subset(type %in% c("fen","fen_fringe", "grassland", "fell_barren", "heath", "salix")), aes(ymin = ybegin, ymax = yend, color = type), size = 1, alpha = 1, position = position_dodge2(width = 0.3)) +
        geom_line(data = vegetation_fluxes2 %>% subset(type %in% c("Rylek�rene","Valley floor")), aes(x = year, y = flux_scaled, group = type, color = type, linetype = type), alpha = 1 , size = 1) +
        geom_point(data = vegetation_fluxes2 %>% subset(type %in% c("Rylek�rene","Valley floor")), aes(x = year, y = flux_scaled, group = type, color = type, shape = type), alpha = 1 , size = 2) +
        geom_errorbar(data = vegetation_fluxes2 %>% subset(type %in% c("Rylek�rene","Valley floor")), aes(x = year, ymin = flux_scaled - se_scaled, ymax = flux_scaled + se_scaled, group = type, color = type, linetype = type), width = 0.1, size =1, alpha =1) +
        theme_pubr() +
        facet_wrap(~area, nrow = 2, scales="free_y") +
        geom_hline(yintercept = 0, lty = "dashed") +
        scale_x_continuous(name = "Year", breaks = seq(2006, 2019, by = 1)) +
        scale_y_continuous(expression(Landscape~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"}))) +
        scale_color_manual(values = c("fen" = "#196580", "fen_fringe" = "#7bafde", "grassland" = "#4eb265", "fell_barren" = "#f7e456", "heath" = "#f1932d", "salix" = "#dc050c", "Rylek�rene" = "black", "Valley floor" = "#A5170E"), labels = c("Fens", "Fen fringes", "Grasslands",  "Fell and barren", "Heaths",  "Salix snowbeds")) + 
        scale_fill_manual(values = c("fen" = "#196580", "fen_fringe" = "#7bafde", "grassland" = "#4eb265", "fell_barren" = "#f7e456", "heath" = "#f1932d", "salix" = "#dc050c"), labels = c("Fens", "Fen fringes", "Grasslands",  "Fell and barren", "Heaths", "Salix snowbeds")) +
        scale_linetype_manual(values = c("solid", "solid"), labels = c("Rylek�rene", "Valley floor")) +
        scale_shape_manual(values = c(16, 16)) +      
        theme(legend.title = element_blank(),
              legend.justification = c(1, 1), 
              legend.position = "none", #c(0.99,0.99),
              legend.spacing = unit(0.5, "cm"),
              legend.key.size =  unit(0.5, "cm"),
              legend.spacing.y = unit(0.25, "cm"),
              axis.ticks = element_line(size = 0.5),
              legend.margin = margin(2,2, 2, 2)) +
        guides(colour = guide_legend(order = 1, ncol =3),
               fill = guide_legend(order = 1),
               linetype = guide_legend(order = 1),
               shape = guide_legend(order =1 ))




fig06 # small adjustments are added afterwards, all the labels could not be added in one round. Executing the part below will delete the customized plot in the figures folder.

# Save plot to "figures" folder
# ggsave(fig06,
#        filename = "figures/fig06.png", 
#        bg = "white",
#        units = "cm", 
#        width = 24, 
#        height = 18, 
#        pointsize = 2, 
#        dpi = 400, 
#        device = "png")    
