# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)
library(viridis)

# Palettes ----------------------------------------------------------------


# Data -------------------------------------------------------------------

study_table <- read_excel("data/Studies_table.xlsx")

# Data preparations ------------------------------------------------------

study_table$newdate <- strptime(as.character(study_table$start_date), "%Y-%m-%d") # converting dates to right format
study_table$start_date2 <- format(study_table$newdate, "%j") # day of year
study_table$newdate <- strptime(as.character(study_table$end_date), "%Y-%m-%d")
study_table$end_date2 <- format(study_table$newdate, "%j")

study_table$Study <- factor(study_table$Study, levels = c("Christensen et al. (2000)", # arrange by publication year
                                                          "Friborg et al. (2000)", 
                                                          "Joabsson and Christensen (2001)", 
                                                          "Ström et al. (2012)", 
                                                          "Tagesson et al. (2012)", 
                                                          "AC 1 to 6: Mastepanov et al. (2013)", 
                                                          "Tagesson et al. (2013)", 
                                                          "Falk et al. (2014)", 
                                                          "Jørgensen et al. (2015)", 
                                                          "Ström et al. (2015)", 
                                                          "Pirk et al. (2016)",
                                                          "AC 1 to 6: Mastepanov et al. (in prep.)", 
                                                          "AC 7 to 10: Mastepanov et al. (in prep.)"))

study_table$period <- factor(study_table$period, levels = c("1997-2000", "2006-2019"), labels = c("1997\u20132000", "2006\u20132019")) # make facets with en dashes


# Figure 7 ----------------------------------------------------------------

plot_studies_duration <- ggplot(data = study_table, aes(color = Study)) +
          geom_linerange(aes(x = reorder(year, desc(year)), ymin = as.numeric(start_date2), ymax = as.numeric(end_date2)), 
                         position = position_dodge2(preserve = "single", width = 1), lwd = 1.4) +
          coord_flip() +
          theme_pubr() +
          theme(legend.title = element_blank(),
                legend.justification = c(0, 1), 
                legend.position = c(0, 1),
                legend.background = element_blank(),
                strip.background = element_rect(color = NA, fill = "grey80"), 
                legend.spacing.x = unit(0.25, 'cm'),
                legend.key.size =  unit(0.5, "cm"),
                legend.margin = margin(2, 2, 2, 2)) +
          scale_y_continuous(breaks = seq(0, 365, by = 10)) +
          labs(x = "Year", y = "DOY" ) +
          facet_grid(rows = vars(period), scales = "free_y", space = "free") +
          scale_color_viridis(discrete = TRUE) +
          geom_vline(xintercept = seq(0.5, 18.5, 1), lwd = 0.25, colour = "#FFFFFF") +
          geom_hline(yintercept = c(182, 243), color = "black", lwd = 0.5, alpha = 0.2)

plot_studies_duration
# 
# ggsave(plot_studies_duration,
#        filename = "figures/fig02.png", 
#        bg = "white",
#        units = "cm",
#        width = 24, 
#        height = 20, 
#        pointsize = 6, 
#        dpi = 400, 
#        device = "png")
