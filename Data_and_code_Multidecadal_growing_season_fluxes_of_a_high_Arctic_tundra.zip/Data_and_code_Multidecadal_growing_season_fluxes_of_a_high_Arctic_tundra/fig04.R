# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Palettes ----------------------------------------------------------------

palette_timeline <- c("#882E72", "#196580", "#5289C7", "#7BAFDE", "#4EB265",  "#90C987","#CAE0AB", "#F7E456", "#F1932D", "#DC050C", "#A5170E")

# Data -------------------------------------------------------------------

flux_studies_timeline <- read_excel("data/Flux_studies_timeline.xlsx")

# Data preparations ------------------------------------------------------

flux_studies_timeline$Publication <- factor(flux_studies_timeline$Publication, levels = c("Christensen et al. (2000)",
                                                                            "Friborg et al. (2000)", 
                                                                            "Joabsson and Christensen (2001)", 
                                                                            "Ström et al. (2012)",
                                                                            "Tagesson et al. (2012)",
                                                                            "AC 1 to 6: Mastepanov et al. (2013)",
                                                                            "Tagesson et al. (2013)",
                                                                            "Falk et al. (2014)", 
                                                                            "Ström et al. (2015)",
                                                                            "AC 1 to 6: Mastepanov et al. (in prep.)", 
                                                                            "AC 7 to 10: Mastepanov et al. (in prep.)"))

flux_studies_timeline$Period <- factor(flux_studies_timeline$Period, levels = c("1997-2000", "2006-2019"), labels = c("1997\u20132000", "2006\u20132019"))


# Figure 8 ----------------------------------------------------------------


plot_flux_studies_timeline <- ggplot(flux_studies_timeline, aes(x = Year)) +
          geom_line(aes(y = Flux_mgm2h, color = Publication, group = Group), size = 1) +
          geom_point(aes(y = Flux_mgm2h, color = Publication), size = 2) +  
          geom_errorbar(aes(ymin = Flux_mgm2h - errorbars, ymax = Flux_mgm2h + errorbars, color = Publication), width = 0.2, size = 1) +
          labs(x = "Year", y = expression(Measured~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"}))) +
          theme_pubr() +
          theme(legend.title = element_blank(),
                legend.justification = c(1, 1),
                axis.ticks = element_line(size = 0.5),
                legend.position = c(0.99, 0.99),
                legend.background = element_blank(),
                legend.spacing = unit(0.5, "cm"),
                legend.key.size =  unit(0.5, "cm"),
                legend.margin = margin(2, 2, 2, 2),
                legend.box = "vertical",
                legend.box.just = "right") +
          scale_y_continuous(breaks = seq(0, 9, by = 1)) +
          scale_color_manual(values = palette_timeline) +
          scale_x_continuous(breaks = seq(1997, 2019, by = 1)) +
          facet_grid(~Period, scales = "free_x", space = "free")  +
          guides(colour = guide_legend(order = 1, ncol = 2), 
                 shape = guide_legend(order = 2, label.position = "right"))


plot_flux_studies_timeline

# 
# ggsave(plot_flux_studies_timeline,
#        filename = "figures/fig04.png", 
#        bg = "white",
#        units = "cm",
#        width = 24, 
#        height = 18, 
#        pointsize = 2, 
#        dpi = 400, 
#        device = "png")
