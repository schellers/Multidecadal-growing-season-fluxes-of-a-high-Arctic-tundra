
# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

vegetation_fluxes <- read_excel("data/vegetation_class_fluxes.xlsx") # simplified results based on Tagesson/Christensen/Jørgensen


models1 <- read_excel("data/workbook.xlsx", sheet = "valleyR") %>% pivot_wider(names_from = bounds, values_from = valleyflux_mgm2h1)
measur <- vegetation_fluxes %>% subset(type == "Valley floor") %>% filter(between(year, 2008, 2019)) %>% select(c(1,2,3,4)) %>% mutate(low = flux - se, high = flux + se) %>% select(-c(4))
colnames(measur) <- c("year", "scenario", "mid", "low", "high")

measur$scenario <- ifelse(measur$year <= 2015, "initial", "measurement")
measur1 <- measur %>% subset(year == 2016) %>% mutate(scenario = "initial")


models <- rbind(models1, measur, measur1) 


summaries4160 <- models %>%
        filter(between(year,2041,2060)) %>%
        group_by(scenario) %>%
        summarise_if(is.numeric, mean)

summaries8100 <- models %>%
        filter(between(year,2081,2100)) %>%
        group_by(scenario) %>%
        summarise_if(is.numeric, mean)

summaries1619 <- models %>%
        filter(between(year,2016,2019)) %>%
        group_by(scenario) %>%
        summarise_if(is.numeric, mean)



library(ggbrace)

models$scenarios <- base::factor(models$scenario, levels = c("initial", "measurement", "RCP8.5", "RCP8.5_01-01gully", "RCP8.5_01-05gully", "RCP8.5_01-10gully"), ordered = TRUE)

sensitivitymodel <-ggplot(models, aes(x = year)) + 
        geom_ribbon(data = models %>% subset(scenarios != "RCP8.5"), aes(fill = scenarios, color = scenarios, x = year, ymin = low, ymax = high), linetype = "longdash", alpha = 0.05, size = 0.5) +
        geom_ribbon(data = models %>% subset(scenarios == "RCP8.5"), aes(fill = scenarios, color = scenarios, x = year, ymin = low, ymax = high), linetype = "longdash", alpha = 0.05, size = 0.5) +  
        geom_line(data = models %>% subset(scenarios != "RCP8.5"), aes(color = scenarios, x = year, y = mid), alpha = 0.9, size = 1) +
        geom_line(data = models %>% subset(scenarios == "RCP8.5"), aes(color = scenarios, x = year, y = mid), alpha = 0.9, size = 1) +
        theme_pubr() +
        scale_y_continuous(breaks = seq(0, 1, by = 0.1), limits = c(0,1), expression(Valley~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"}))) +
        scale_color_manual(values = c("grey60", "black", "#7BAFDE", "#90C987", "#F1932D", "#A5170E"), 
                           labels = c("Calculated flux, 2008\u20132015 (a)", 
                                      "Calculated flux, 2016\u20132019 (b)", 
                                      "Modeled flux and no erosion (c)", 
                                      bquote("Modeled flux and +720 m"^"2"~"erosion year"^{"\u20131"}~"(d)"), 
                                      bquote("Modeled flux and +720 m"^"2"~"to +3600 m"^"2"~"erosion year"^{"\u20131"}~"(e)"),
                                      bquote("Modeled flux and +720 m"^"2"~"to +7200 m"^"2"~"erosion year"^{"\u20131"}~"(f)"))) + 
        scale_fill_manual(values = c("grey60", "black", "#7BAFDE", "#90C987", "#F1932D", "#A5170E"), 
                          labels = c("Calculated flux, 2008\u20132015 (a)", 
                                     "Calculated flux, 2016\u20132019 (b)", 
                                     "Modeled flux and no erosion (c)", 
                                     bquote("Modeled flux and +720 m"^"2"~"erosion year"^{"\u20131"}~"(d)"), 
                                     bquote("Modeled flux and +720 m"^"2"~"to +3600 m"^"2"~"erosion year"^{"\u20131"}~"(e)"),
                                     bquote("Modeled flux and +720 m"^"2"~"to +7200 m"^"2"~"erosion year"^{"\u20131"}~"(f)"))) + 
        scale_x_continuous(name = "Year", breaks = seq(2010, 2100, by = 10)) +
        theme(legend.title = element_blank(),
              legend.justification = c(0, 1), 
              legend.position = c(0.01, 1),
              legend.spacing.y = unit(0.5, "cm"),
              legend.key.size = unit(0.5, "cm"),
              axis.ticks = element_line(size = 0.5),
              legend.margin = margin(2, 2, 2, 2)) +
        guides(colour = guide_legend(order = 1, ncol = 2),
               fill = guide_legend(order = 1)) +
        geom_brace(aes(c(2008, 2015), c(0.122, 0.092), label = "2008\u20132015\nMean flux and bounds\n(a) 0.270 [0.180, 0.359]"), labelsize = 3, inherit.data = FALSE, rotate = 180) +
        geom_brace(aes(c(2016, 2019), c(0.655, 0.685), label = "2016\u20132019\nMean flux and bounds\n(b) 0.389 [0.261, 0.517]"), labelsize = 3, inherit.data = FALSE, rotate = 0) +
        geom_brace(aes(c(2041, 2060), c(0.207, 0.177), label = "2041\u20132060\nMean flux and bounds\n(c) 0.419 [0.252, 0.601]\n(d) 0.418 [0.251, 0.601]\n(e) 0.416 [0.250, 0.608]\n(f) 0.414 [0.248, 0.594]"),  labelsize = 3, inherit.data=FALSE, rotate = 180) +
        geom_brace(aes(c(2081, 2100), c(0.289, 0.259), label = "2081\u20132100\nMean flux and bounds\n(c) 0.594 [0.344, 0.889]\n(d) 0.589 [0.340, 0.891]\n(e) 0.578 [0.333, 0.877]\n(f) 0.565 [0.324, 0.859]"), labelsize = 3, inherit.data=FALSE, rotate = 180)      




sensitivitymodel



# ggsave(sensitivitymodel,
#        filename = "figures/fig07.png", 
#        bg = "white",
#        units = "cm", 
#        width = 24, 
#        height = 18, 
#        pointsize = 2, 
#        dpi = 400, 
#        device = "png")          