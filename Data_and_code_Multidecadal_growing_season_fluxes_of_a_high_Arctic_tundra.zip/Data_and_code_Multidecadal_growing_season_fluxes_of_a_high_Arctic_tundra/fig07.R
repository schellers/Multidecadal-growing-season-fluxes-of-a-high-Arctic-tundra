# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Palettes ----------------------------------------------------------------

palette_campaigns <- c("#882E72", "#196580", "#5289C7", "#7BAFDE", "#4EB265", "#90C987", "#CAE0AB", "#F7E456", "#F6C141", "#F1932D", "#E8601C", "#DC050C", "#A5170E")

# Data -------------------------------------------------------------------

study_table <- read_excel("data/Studies_table.xlsx")

# Data preparations ------------------------------------------------------

study_table$newdate <- strptime(as.character(study_table$start_date), "%Y-%m-%d") # converting dates to right format
study_table$start_date2 <- format(study_table$newdate, "%j") # day of year
study_table$newdate <- strptime(as.character(study_table$end_date), "%Y-%m-%d")
study_table$end_date2 <- format(study_table$newdate, "%j")

study_table$Study <- factor(study_table$Study, levels = c("Christensen et al. (2000)", # arrange by publication year
                                                          "Friborg et al. (2000)", 
                                                          "Joabsson and Christensen (2001)", 
                                                          "Ström et al. (2012)", 
                                                          "Tagesson et al. (2012)", 
                                                          "AC 1 to 6: Mastepanov et al. (2013)", 
                                                          "Tagesson et al. (2013)", 
                                                          "Falk et al. (2014)", 
                                                          "Jørgensen et al. (2015)", 
                                                          "Ström et al. (2015)", 
                                                          "Pirk et al. (2016)",
                                                          "AC 1 to 6: Mastepanov et al. (in prep.)", 
                                                          "AC 7 to 10: Mastepanov et al. (in prep.)"))

study_table$period <- factor(study_table$period, levels = c("1997-2000", "2006-2019"), labels = c("1997\u20132000", "2006\u20132019")) # make facets with en dashes


# Figure 7 ----------------------------------------------------------------

plot_studies_duration <- ggplot(data = study_table, aes(color = Study)) +
          geom_linerange(aes(x = reorder(year, desc(year)), ymin = as.numeric(start_date2), ymax = as.numeric(end_date2)), 
                         position = position_dodge2(preserve = "single", width = 1), lwd = 1.5) +
          coord_flip() +
          theme_pubr(base_size = 10, base_family = "") +
          theme(legend.title = element_blank(),
                legend.justification = c(0, 1), 
                legend.position = c(0, 1),
                legend.background = element_blank(),
                strip.background = element_rect(color = NA, fill = "grey80"), 
                strip.text.y = element_text(size = 10),
                legend.spacing.x = unit(0.2, 'cm'),
                legend.key.size =  unit(0.25, "cm"),
                legend.text = element_text(size = 7),
                legend.margin = margin(2, 2, 2, 2)) +
          scale_y_continuous(breaks = seq(0, 365, by = 10)) +
          labs(x = "Year", y = "DOY" ) +
          facet_grid(rows = vars(period), scales = "free_y", space = "free") +
          scale_color_manual(values = palette_campaigns) +
          geom_vline(xintercept = seq(0.5, 18.5, 1), lwd = 0.25, colour = "#FFFFFF") +
          geom_hline(yintercept = c(182, 243), color = "black", lwd = 0.5, alpha = 0.2)

plot_studies_duration

ggsave(plot_studies_duration,
       filename = "figures/fig07_1.png", 
       bg = "white",
       units = "cm",
       width = 18, 
       height = 12, 
       pointsize = 8, 
       dpi = 300, 
       device = "png")

# Figure 7 top right corner ----------------------------------------------------------------

year <- c(1996, 1998,2001, 2002, 2003, 2004, 2005)
Study <- NA
start_date <- NA
end_date <- NA
period <- NA
newdate <- NA
start_date2 <- NA
end_date2 <- NA

addon <- data_frame(year, Study, start_date, end_date, period, newdate, start_date2, end_date2)

study_table2 <- rbind(study_table, addon)

plot_studies_duration_mini <- ggplot(data = study_table2, color = "black") +
          geom_linerange(aes(x = reorder(year, desc(year)), ymin = as.numeric(start_date2), ymax = as.numeric(end_date2)),
                         position = position_dodge( width = 3), lwd = 2.5) +
          coord_flip() +
          theme_classic() +
          scale_y_continuous(breaks = seq(0, 365, by = 90), limits = c(0,365)) +
          theme(axis.title = element_text(size = 8),
                axis.text = element_text(size = 8, color = "black"),
                axis.ticks = element_line(size = 0.25),
                axis.line = element_blank()) +
          scale_x_discrete(breaks = c("2000", "2005", "2010", "2015")) +
          labs(x = "Year", y = "DOY") 

plot_studies_duration_mini

# Save plot to 'outputs' folder
ggsave(plot_studies_duration_mini,
       filename = "figures/fig07_2.png", 
       bg = "white",
       units = "cm",
       width = 8, 
       height = 6, 
       pointsize = 4, 
       dpi = 300, 
       device = "png")

# The two figures are combined in a photo editing program

# Tidy up environment
rm(list = ls(all.names = TRUE)) 