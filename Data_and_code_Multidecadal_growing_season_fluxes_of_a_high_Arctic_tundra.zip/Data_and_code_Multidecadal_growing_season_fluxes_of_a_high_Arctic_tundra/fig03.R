# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries --------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Color palette ----------------------------------------------------------

palette_ac <- c("#AE76A3", "#196580", "#7BAFDE", "#90C987", "#F4E455", "#F1932D", "#DC050C")

# Data -------------------------------------------------------------------

ac <- read_excel("data/AC_fluxes_2006-2019.xlsx", guess_max = 17000) # excel table consisting of all chamber time series from 2006-2019


# Data preparation --------------------------------------------------------

ac_ja_1to6 <- ac %>%
          mutate(Datetime = ymd_hms(Datetime)) %>%
          mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
          mutate(hours = as.numeric(format(Datetime, "%H"))) %>% # conversion of text format to months/dates/hours
          filter(between(monthday, 701, 831)) %>% # july and august
          mutate(year = year(Datetime)) %>% # extract year from time column 
          mutate(n_obs = rowSums(!is.na(.[,2:7]))) %>% # sum number of observations per time interval
          group_by(year) %>%
          summarize(mean_1 = mean(CH1, na.rm = TRUE), # mean of all non-NA measurements at Chamber 1 and so on
                    mean_2 = mean(CH2, na.rm = TRUE),
                    mean_3 = mean(CH3, na.rm = TRUE),
                    mean_4 = mean(CH4, na.rm = TRUE),
                    mean_5 = mean(CH5, na.rm = TRUE),
                    mean_6 = mean(CH6, na.rm = TRUE),
                    mean_1to6 = mean(c(mean_1, mean_2, mean_3, mean_4, mean_5, mean_6)), # mean of the six chamber means
                    SE_1 = sd(CH1, na.rm = TRUE)/sqrt(sum(!is.na(CH1))), # standard errors (se) of all non-NA measurements at Chamber 1 and so on
                    SE_2 = sd(CH2, na.rm = TRUE)/sqrt(sum(!is.na(CH2))),
                    SE_3 = sd(CH3, na.rm = TRUE)/sqrt(sum(!is.na(CH3))),
                    SE_4 = sd(CH4, na.rm = TRUE)/sqrt(sum(!is.na(CH4))),
                    SE_5 = sd(CH5, na.rm = TRUE)/sqrt(sum(!is.na(CH5))),
                    SE_6 = sd(CH6, na.rm = TRUE)/sqrt(sum(!is.na(CH6))),
                    SE_1to6 = sd(c(mean_1, mean_2, mean_3, mean_4, mean_5, mean_6), na.rm = TRUE)/sqrt(6), # standard error on the mean measurements
                    count_1 = sum(!is.na(CH1)), # count number of non-NA measurements
                    count_2 = sum(!is.na(CH2)),
                    count_3 = sum(!is.na(CH3)),
                    count_4 = sum(!is.na(CH4)),
                    count_5 = sum(!is.na(CH5)),
                    count_6 = sum(!is.na(CH6))) %>%
          gather(key, value = mgm2h, -year) %>%  separate(key, into = c("stat", "chamber"), sep = "_") %>% # reorder to narrow table, separate into stat column (mean, se, and count) and chamber column @ underscore
          spread(stat, mgm2h) # separate stat column into mean, se, and count columns

ac_ja_1to6_all_time <- ac %>% # all time mean and se
          mutate(Datetime = ymd_hms(Datetime)) %>%
          mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
          mutate(hours = as.numeric(format(Datetime, "%H"))) %>% # conversion of text format to months/dates/hours
          filter(between(monthday, 701, 831)) %>% # dates 07-01 to 08-31
          select(-c(8:11)) %>%
          mutate(year = year(Datetime)) %>%
          gather(chamber, value = mgm2h, -year, -monthday, -hours, -Datetime) %>%  summarize(mean_1to6_all_time = mean(mgm2h, na.rm = TRUE), SE_1to6 = sd(mgm2h, na.rm = TRUE)/sqrt(length(which(!is.na(mgm2h)))))

ac_ja_7to10_all_time <- ac %>% # all time mean and SE
          mutate(Datetime = ymd_hms(Datetime)) %>%
          mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
          mutate(hours = as.numeric(format(Datetime, "%H"))) %>% # conversion of text format to months/dates/hours
          filter(between(monthday, 701, 831)) %>% # dates 07-01 to 08-31
          select(-c(2:7)) %>%
          mutate(year = year(Datetime)) %>%
          gather(chamber, value = mgm2h, -year, -monthday, -hours, -Datetime) %>%  summarize(mean_1to6_all_time = mean(mgm2h, na.rm =TRUE), SE_1to6 = sd(mgm2h, na.rm = TRUE)/sqrt(length(which(!is.na(mgm2h)))))


ac_ja_1to6_all <- subset(ac_ja_1to6, chamber == "1to6") %>% # only "1to6"
          mutate(mean = replace(mean, year == 2006, 2.266324498*0.912346509 )) %>% # make a new data frame with only mean measurements from chamber 1-6, and correction for 2006's 4 chamber setup. 0.912346509 should be used as scale factor for mean for 4 chambers (2.26 mg h-1 m-2)
          mutate(anomaly = mean - mean(mean)) # make a new column with anomalies

ac_ja_1to6_indi <- subset(ac_ja_1to6, chamber != "1to6") %>% # make a new dataframe with measurements from each of the chambers 1-6, omit "1to6"
          mutate(anomaly = mean - mean(ac_ja_1to6_all$mean)) # make a new column with anomalies

ac_1to6 <- ac_ja_1to6_indi %>%
          group_by(chamber) %>%
          mutate(year =  year + runif(1, -0.15, 0.15)) %>% # add a random offset to avoid overplotting
          ungroup()


# Figure 3 ----------------------------------------------------------------

plot_ac_1to6 <- ggplot(ac_1to6, aes(x = year)) + # default data is data from all six chambers, separated
          geom_line(data = ac_ja_1to6_all, aes(x = year, y = mean, color = "Mean 1-6"), alpha = 1) + # plot a mean line
          geom_point(data = ac_ja_1to6_all, aes(x = year, y = mean, color = "Mean 1-6"), alpha = 1) + # plot points
          geom_errorbar(data = ac_ja_1to6_all, aes(ymin = mean - SE, ymax = mean + SE, color = "Mean 1-6"), width = 0.1,  alpha = 1) + # plot error bars
          geom_errorbar(aes(ymin = mean - SE, ymax = mean + SE, color = chamber), width = 0.2, alpha = 1) + # plot the next set of error bars
          geom_point(aes(y = mean, color = chamber), alpha = 1) +
          theme_pubr(base_size = 10, base_family = "") +
          theme(legend.title = element_blank(),
                legend.justification = c(1, 1), 
                legend.position = c(1, 1),
                legend.spacing.x = unit(0.2, "cm"),
                legend.key.size =  unit(0.25, "cm"),
                axis.ticks = element_line(size = 0.25),
                legend.margin = margin(2, 2, 2, 2)) +
          scale_x_continuous(name = "Year", breaks = seq(2006, 2019, by = 1)) +
          scale_y_continuous(expression(Measured~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})),
                             breaks = seq(-1, 6.5, 0.5), limits = c(0, 6.5)) + # mean from all inner chambers, 2006-2019
          scale_color_manual(values = palette_ac, labels = c("Chamber 1 (n = 289 to 1447)", "Chamber 2 (n = 304 to 1471)", "Chamber 3 (n = 243 to 1471)",
                                                             "Chamber 4 (n = 335 to 1329)", "Chamber 5 (n = 326 to 1477)", "Chamber 6 (n = 299 to 1286)", "Chamber 1 to 6 mean* (n = 4 to 6)")) # n differs from year to year, this shows the range over the period

plot_ac_1to6

# Save plot to "figures" folder
ggsave(plot_ac_1to6,
       filename = "figures/fig03.png", 
       bg = "white",
       units = "cm", 
       width = 18, 
       height = 12, 
       pointsize = 8, 
       dpi = 300, 
       device = "png")


# Chambers 7 to 10 (2012-2019) --------------------------------------------

ac_ja_7to10 <- ac %>%
        mutate(Datetime = ymd_hms(Datetime)) %>%
        mutate(monthday = as.numeric(format(Datetime, "%m%d"))) %>%
        mutate(hours = as.numeric(format(Datetime, "%H"))) %>%
        filter(between(monthday, 701, 831)) %>% # dates 07-01 to 08-31
        mutate(year = year(Datetime)) %>%
        filter(between(year, 2012, 2019)) %>% # years 2012 to 2019
        mutate(n_obs = rowSums(!is.na(.[,8:11]))) %>% # sum number of observations per time interval
        group_by(year) %>%
        summarize(mean_7 = mean(CH7, na.rm = TRUE),
                  mean_8 = mean(CH8, na.rm = TRUE),
                  mean_9 = mean(CH9, na.rm = TRUE),
                  mean_10 = mean(CH10, na.rm = TRUE),
                  mean_7to10 = mean(c(mean_7, mean_8, mean_9, mean_10)),
                  SE_7 = sd(CH7, na.rm = TRUE)/sqrt(sum(!is.na(CH7))),
                  SE_8 = sd(CH8, na.rm = TRUE)/sqrt(sum(!is.na(CH8))),
                  SE_9 = sd(CH9, na.rm = TRUE)/sqrt(sum(!is.na(CH9))),
                  SE_10 = sd(CH10, na.rm = TRUE)/sqrt(sum(!is.na(CH10))),
                  SE_7to10 = sd(c(mean_7, mean_8, mean_9, mean_10), na.rm = TRUE)/sqrt(4),
                  count_7 = sum(!is.na(CH7)),
                  count_8 = sum(!is.na(CH8)),
                  count_9 = sum(!is.na(CH9)),
                  count_10 = sum(!is.na(CH10))) %>%
        gather(key, value = mgm2h, -year) %>%  separate(key, into = c("stat", "chamber"), sep = "_") %>%
        spread(stat, mgm2h)

ac_ja_7to10_all <- subset(ac_ja_7to10, chamber == "7to10") %>% 
        mutate(anomaly = mean - mean(mean))
ac_ja_7to10_indi <- subset(ac_ja_7to10, chamber != "7to10") %>%
        mutate(anomaly = mean - mean(ac_ja_7to10_all$mean))

ac_7to10 <- ac_ja_7to10_all %>%
        group_by(chamber) %>%
        mutate(year =  year + runif(1, -0.15, 0.15)) %>%
        ungroup()

