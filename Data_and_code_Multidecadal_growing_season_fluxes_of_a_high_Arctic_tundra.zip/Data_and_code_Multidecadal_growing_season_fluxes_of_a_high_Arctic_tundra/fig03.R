# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ----------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Data ---------------------------------------------------------------

# Air temperature
zac_airt <- read_delim("data/View_ClimateBasis_Zackenberg_Data_Temperature_Air_temperature_200cm__60min_average.csv", "\t", escape_double = FALSE, na = "-9999",  trim_ws = TRUE) # (https://doi.org/10.17897/xv96-hc57)

# Soil temperature
zac_soilt <- read_delim("data/View_ClimateBasis_Zackenberg_Data_Temperature_Soil_temperature_20cm__60min_average.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/xw7c-na36)

# Snow melt
zac_s <- read_excel("data/snowmelt_pedersen_geobasis.xlsx") %>% mutate(title = "Day of 20 % snow cover on the valley floor")# xix of Pedersen et al. (2016) and data from the GEM database (https://doi.org/10.17897/499c-h459)

# Soil moisture (Heath)
mix_soilm <- read_delim("data/View_GeoBasis_Zackenberg_Data_Soil_properties_Mix1_Soil_moisture.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/ennb-t831)

# Soil moisture (AC)
zwm <- read_delim("data/View_GeoBasis_Zackenberg_Data_Hydrology_AC_Water_level_manual.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/6hcp-m521)

zwa <- read_delim("data/View_GeoBasis_Zackenberg_Data_Hydrology_AC_Water_level_automatic.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/mj7b-z461)

# Data preparation --------------------------------------------------------

zac_t <- zac_airt %>%
          mutate(datetime = ymd_hms(paste(Date,Time))) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>% 
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
          dplyr::summarize(meanT_ja = mean(as.numeric(`AT (�C)`), na.rm = TRUE)) # summarize as july-august mean per year, remove missing data

zac_st <- zac_soilt %>%
          mutate(datetime = ymd_hms(paste(Date,Time))) %>% 
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
        dplyr::summarize(meanST_ja = mean(as.numeric(`Soil temperature, 20cm - 60min average (�C)`), na.rm = TRUE)) # summarize as july-august mean per year, remove missing data

zac_temp <- left_join(zac_t, zac_st, by = "year") %>% # join the two temperature datasets 
          gather(Legend, deg, -year) %>%
        mutate(title = "Climate station mean temperatures")

zac_sm <- mix_soilm %>%
          mutate(datetime = ymd_hm(paste(Date,Time))) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
        dplyr::summarize(meanSM_ja = mean(as.numeric(`Soil_moisture_5_cm_vol_%`), na.rm = TRUE), # summarize as july-august mean per year, remove missing data
                    meanSM_ja_sd = sd(as.numeric(`Soil_moisture_5_cm_vol_%`), na.rm = TRUE)) %>%
        mutate(title = "Heath mean soil moisture")# added calculation of standard deviation, remove missing data

zac_wa1 <- zwa %>%
          mutate(datetime = ymd(paste(Date))) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
        group_by(Date) %>%
        mutate(mean_wl_1 = mean(Water_level_K1_relative_to_surface_cm)) %>% # some two week gaps in 2012 and 2014, still used though
        distinct(Date, .keep_all = TRUE) %>%
        group_by(year) %>%
        summarize(mean_wl = mean(mean_wl_1, na.rm = TRUE), sd_wl = sd(mean_wl_1, na.rm = TRUE), place = "Chamber 1", method = "automatic")
        
zac_wa6 <- zwa %>%
        mutate(datetime = ymd(paste(Date))) %>%
        mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
        mutate(year = year(datetime)) %>%
        filter(between(monthday, 701, 831)) %>% # july and august
        filter(between(year, 1997, 2019)) %>% # only 1997-2019
        group_by(Date) %>%
        mutate(mean_wl_6 = mean(Water_level_K6_relative_to_surface_cm)) %>% # some two week gaps in 2012 and 2014, still used though
        distinct(Date, .keep_all = TRUE) %>%
        group_by(year) %>%
        summarize(mean_wl = mean(mean_wl_6, na.rm = TRUE), sd_wl = sd(mean_wl_6, na.rm = TRUE), place = "Chamber 6", method = "automatic")

zac_wm <- zwm %>%
          mutate(datetime = ymd(paste(Date))) %>%
          mutate(aWaterM1 = as.numeric(Water_level_relative_to_surface_cm)) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>%
        group_by(Date) %>%
        mutate(mean_wl_m = mean(Water_level_relative_to_surface_cm)) %>%
        distinct(Date, .keep_all=TRUE) %>%
        group_by(year) %>%
        summarize(mean_wl = mean(Water_level_relative_to_surface_cm, na.rm = TRUE), sd_wl = sd(Water_level_relative_to_surface_cm, na.rm = TRUE), place = "Chamber 1", method = "manual")
        
gap2013_1 <- c(2013, NaN, NaN, "Chamber 1", "automatic")        
gap2013_2 <- c(2013, NaN, NaN, "Chamber 6", "automatic")

zac_w <- rbind(zac_wa1, zac_wa6, zac_wm, gap2013_1, gap2013_2 ) %>%
        mutate(title = "AC mean water level from surface") %>%
        mutate(places = paste(place,method, sep = ", "))

zac_w$year <- as.numeric(zac_w$year)
zac_w$mean_wl <- as.numeric(zac_w$mean_wl)
zac_w$sd_wl <- as.numeric(zac_w$sd_wl)


zac_w$places <- factor(zac_w$places, levels = c("Chamber 1, manual", "Chamber 1, automatic", "Chamber 6, automatic"))

# Figure 3 ----------------------------------------------------------------

plot_a <- ggplot(zac_temp) +
          geom_line(aes(x = year, y = deg, color = Legend), size = 1) +
          geom_point(aes(x = year, y = deg, color = Legend), size = 1.5) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 5)) +
        facet_wrap(~title) +
          theme_pubr() +
          theme(legend.justification = c(0, 0), 
                legend.position = c(0.01, 0.01),
                legend.title = element_blank()) +
          labs( x = "Year", y = "July\u2013August (�C)") +
          scale_color_manual(values = c("#000000", "#a5a5a5"), labels = c("Soil temperature (0.2 m)","Air temperature (2 m)"))

plot_b <- ggplot(zac_s) +
          geom_line(aes(x = Year, y = Valley_floor_20p_DOY), size = 1) +
          geom_point(aes(x = Year, y = Valley_floor_20p_DOY), size = 1.5) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 5)) +
          scale_y_continuous(breaks = seq(150, 215, by = 10), limits = c(150, 215)) +
          theme_pubr() +
        facet_wrap(~title) +
          labs(x = "Year", y = "DOY")

plot_c <- ggplot(zac_sm) +
          geom_ribbon(aes(x = year, ymin = meanSM_ja - meanSM_ja_sd, ymax = meanSM_ja + meanSM_ja_sd), fill = "#a5a5a5", alpha = 0.6) +
          geom_line(aes(x = year, y = meanSM_ja), size = 1) +
          geom_point(aes(x = year, y = meanSM_ja), size = 1.5) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 5)) +
          theme_pubr() +
        facet_wrap(~title) +
          labs(x = "Year", y = "July\u2013August (%)")

plot_d <- ggplot(zac_w, aes(x = year, y = mean_wl)) +
        geom_line(size = 1, aes(color = places, linetype = places), alpha = 0.9) +
        geom_point(size = 1.5, aes(color = places), alpha = 0.9) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 5)) +
          theme_pubr() +
        facet_wrap(~title) +
          labs(x = "Year", y = "July\u2013August (cm)") +
        scale_color_manual(values = c('#000000', "#505050",'#a5a5a5' ), labels = c("Chamber 1, manual","Chamber 1, automatic", "Chamber 6, automatic")) +
        scale_linetype_manual(values = c( "longdash","solid","solid"), labels = c("Chamber 1, manual","Chamber 1, automatic", "Chamber 6, automatic")) +
        theme(legend.justification = c(0, 0), 
              legend.position = c(0.01, 0.01),
              axis.ticks = element_line(size = 0.5),
              legend.title = element_blank()) +
        guides(colour = guide_legend(order = 1, ncol =1),
               linetype = guide_legend(order = 1))
        

fig03 <- plot_grid(plot_a, plot_b, plot_c, plot_d, labels = c("(a)", "(b)", "(c)", "(d)"), ncol = 2, nrow = 2, hjust = 0) # combine four plots into one, give each of them a label

fig03 # plot finished grid 

# ggsave(fig03,
#        filename = "figures/fig03.png", 
#        bg = "white",
#        units = "cm", 
#        width = 24, 
#        height = 18, 
#        pointsize = 2, 
#        dpi = 400,
#        device = "png") # save as png in figures folder
# 



