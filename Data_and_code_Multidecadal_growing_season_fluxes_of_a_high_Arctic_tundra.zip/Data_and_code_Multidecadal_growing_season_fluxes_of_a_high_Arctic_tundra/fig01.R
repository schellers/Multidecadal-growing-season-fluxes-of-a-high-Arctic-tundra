# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ----------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Data ---------------------------------------------------------------

# Air temperature
zac_airt <- read_delim("data/View_ClimateBasis_Zackenberg_Data_Temperature_Air_temperature_200cm__60min_average.csv", "\t", escape_double = FALSE, na = "-9999",  trim_ws = TRUE) # (https://doi.org/10.17897/xv96-hc57)

# Soil temperature
zac_soilt <- read_delim("data/View_ClimateBasis_Zackenberg_Data_Temperature_Soil_temperature_20cm__60min_average.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/xw7c-na36)

# Snow melt
zac_s <- read_excel("data/snowmelt_pedersen_geobasis.xlsx") # xix of Pedersen et al. (2016) and data from the GEM database (https://doi.org/10.17897/499c-h459)

# Soil moisture (Heath)
mix_soilm <- read_delim("data/View_GeoBasis_Zackenberg_Data_Soil_properties_Mix1_Soil_moisture.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/ennb-t831)

# Soil moisture (AC)
zwm <- read_delim("data/View_GeoBasis_Zackenberg_Data_Hydrology_AC_Water_level_manual.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/6hcp-m521)

zwa <- read_delim("data/View_GeoBasis_Zackenberg_Data_Hydrology_AC_Water_level_automatic.csv", "\t", escape_double = FALSE, na = "-9999", trim_ws = TRUE) # (https://doi.org/10.17897/mj7b-z461)

# Data preparation --------------------------------------------------------
zac_t <- Zac_airt %>%
          mutate(datetime = ymd_hms(paste(Date,Time))) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>% 
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
          summarize(meanT_ja = mean(as.numeric(`AT (°C)`), na.rm = TRUE)) # summarize as july-august mean per year, remove missing data

zac_st <- Zac_soilt %>%
          mutate(datetime = ymd_hms(paste(Date,Time))) %>% 
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
          summarize(meanST_ja = mean(as.numeric(`Soil temperature, 20cm - 60min average (°C)`), na.rm = TRUE)) # summarize as july-august mean per year, remove missing data

zac_temp <- left_join(zac_t, zac_st, by = "year") %>% # join the two temperature datasets 
          gather(Legend, deg, -year)

zac_sm <- Mix_soilm %>%
          mutate(datetime = ymd_hm(paste(Date,Time))) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
          summarize(meanSM_ja = mean(as.numeric(`Soil_moisture_5_cm_vol_%`), na.rm = TRUE), # summarize as july-august mean per year, remove missing data
                    meanSM_ja_sd = sd(as.numeric(`Soil_moisture_5_cm_vol_%`), na.rm = TRUE)) # added calculation of standard deviation, remove missing data
zac_wa <- zwa %>%
          mutate(datetime = ymd(paste(Date))) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year)

zac_wm <- zwm %>% 
          mutate(datetime = ymd(paste(Date))) %>%
          mutate(aWaterM1 = as.numeric(Water_level_relative_to_surface_cm)) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%

zac_w <- full_join(zac_wa, zac_wm, by = "datetime") %>% # join automated and manual data to close gap in data for manual data collection
          pivot_longer(cols = starts_with("aW")) %>%
          mutate(monthday = as.numeric(format(datetime, "%m%d"))) %>%
          mutate(year = year(datetime)) %>%
          filter(between(monthday, 701, 831)) %>% # july and august
          filter(between(year, 1997, 2019)) %>% # only 1997-2019
          group_by(year) %>%
          filter(!is.na(value)) %>%
          mutate(measDays = length(unique(monthday))) %>%
          summarize(mean_wl = mean(value), sd_wl = sd(value))


# Figure 1 ----------------------------------------------------------------

plot_a <- ggplot(zac_temp) +
          geom_line(aes(x = year, y = deg, color = Legend)) +
          geom_point(aes(x = year, y = deg, color = Legend)) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 2)) +
          theme_pubr(base_size = 7, base_family = "") +
          theme(plot.title = element_text(hjust = 0.5),
                legend.title = element_blank(),
                legend.position = c(.5,.2)) +
          labs(title = "Climate station mean temperatures", 
               x = "Year", y = "July–August (°C)") +
          scale_color_manual(values = c("#000000", "#a6a6a6"), labels = c("Soil T (0.2 m)","Air T (2 m)"))

plot_b <- ggplot(zac_S) +
          geom_line(aes(x = Year, y = Valley_floor_20p_DOY)) +
          geom_point(aes(x = Year, y = Valley_floor_20p_DOY)) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 2)) +
          scale_y_continuous(breaks = seq(150, 215, by = 10), limits = c(150, 215)) +
          theme_pubr(base_size = 7, base_family = "") +
          theme(plot.title = element_text(hjust = 0.5)) +
          labs(title = "Day of 20 % snow cover on the valley floor", 
               x = "Year", y = "DOY")

plot_c <- ggplot(zac_sm) +
          geom_ribbon(aes(x = year, ymin = meanSM_ja - meanSM_ja_sd, ymax = meanSM_ja + meanSM_ja_sd), fill = "#a6a6a6", alpha = 0.6) +
          geom_line(aes(x = year, y = meanSM_ja)) +
          geom_point(aes(x = year, y = meanSM_ja)) +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 2)) +
          theme_pubr(base_size = 7, base_family = "") +
          theme(plot.title = element_text(hjust = 0.5)) +
          labs(title = "Heath mean soil moisture", 
               x = "Year", y = "July–August (%)")

plot_d <- ggplot(zac_w, aes(x = year, y = mean_wl)) +
          geom_ribbon(aes(x = year, ymin = mean_wl - sd_wl, ymax = mean_wl + sd_wl), fill = "#a6a6a6", alpha = 0.6) +
          geom_line() +
          geom_point() +
          scale_x_continuous(limits = c(1997, 2019), breaks = seq(1997, 2019, by = 2)) +
          theme_pubr(base_size = 7, base_family = "") +
          theme(plot.title = element_text(hjust = 0.5)) +
          labs(title = "AC mean water level from surface", 
               x = "Year", y = "July–August (cm)")

fig01 <- plot_grid(plot_a, plot_b, plot_c, plot_d, labels = c("(a)", "(b)", "(c)", "(d)"), ncol = 2, nrow = 2, hjust = 0) # combine four plots into one, give each of them a label

fig01 # plot finished grid 

ggsave(fig01,
       filename = "figures/fig01.png", 
       bg = "white",
       units = "cm", 
       width = 18, 
       height = 12, 
       pointsize = 8, 
       dpi = 300,
       device = "png") # save as png in figures folder

# Tidy up environment
rm(list = ls(all.names = TRUE)) 
