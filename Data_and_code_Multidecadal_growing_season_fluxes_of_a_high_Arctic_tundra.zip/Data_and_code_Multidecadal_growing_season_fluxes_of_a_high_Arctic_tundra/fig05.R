# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Please note that the script named 'fig03.R' needs to run before this one

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Data -------------------------------------------------------------------

vegetation_fluxes <- read_excel("data/vegetation_class_fluxes.xlsx") # simplified results based on Tagesson et al. (2013)

# Data preparation -------------------------------------------------------

ac_ja_scaling <- ac_ja_1to6_all %>%
          mutate(scale2007 = mean/mean[year == 2007]) # scale inner six chamber fluxes two mean in year 2007, where measurements from both datasets occur(AC and Tagesson et al. (2013))

# Zone 1A

valley_flux <- vegetation_fluxes %>%
          mutate(total_flux = CH4_mean * Area_1A_u200m_m2) %>% # CH4_mean_flux multiplied with Zone 1A under 200 m (defined by Søgaard et al. 2000)
          mutate(total_se = CH4_se * Area_1A_u200m_m2) %>% # including SE estimate, calculated from SD in tagesson2013
          summarize(zone1A_mean_flux = sum(total_flux) / 15905003, zone1A_se_flux = sum(total_se) / 15905003) # Summarize to two columns: total flux and mean flux in area Zone 1A, number is the area of Zone1Au200m

valley_flux <- as.data.frame(valley_flux)

temporal_valley_flux <- ac_ja_scaling %>%
          mutate(t2013m = rep(valley_flux[1,1])) %>% # fill column with mean valley flux
          mutate(t2013se = rep(valley_flux[1,2])) %>% # fill column with se valley flux
          mutate(t2013meanfluxvalley = t2013m * scale2007) %>% # m is the mean flux in the valley in 2007
          mutate(t2013sefluxvalley = ((SE / mean[year == 2007]) + t2013se * scale2007)) # all se are scaled to 2007 mean, then, scaled tagesson se for the valley is added

# Rylekærene

rylekaerene_flux <- vegetation_fluxes %>%
          mutate(total_flux = CH4_mean * Area_Rylekaerene_m2) %>% # CH4_mean_flux multiplied with Rylekærene (defined in Tagesson et al. 2013)
          mutate(total_se = CH4_se * Area_Rylekaerene_m2) %>% # including SE estimate, calculated from SD in tagesson2013
          filter(Publication == "T2013") %>%
          summarize(Ryl_mean_flux = sum(total_flux) / 1271303, Ryl_se_flux = sum(total_se) / 1271303)

rylekaerene_flux <- as.data.frame(rylekaerene_flux)

temporal_rylekaerene_flux <- ac_ja_scaling %>%
          mutate(t2013m = rep(rylekaerene_flux[1,1])) %>%
          mutate(t2013se = rep(rylekaerene_flux[1,2])) %>%
          mutate(t2013meanfluxryle = t2013m * scale2007) %>% 
          mutate(t2013sefluxryle = ((SE / mean[year == 2007]) + t2013se * scale2007)) # scaled SE

temporal_rylekaerene_flux$location <- "ryl" # short names are easier to deal with
temporal_valley_flux$location <- "val"

ryl <- select(temporal_rylekaerene_flux, year, t2013meanfluxryle, t2013sefluxryle, location) %>%
          gather(key = "stat", value = flux, -year, -location) %>%
          spread(stat, flux) %>%
          rename(meanflux = t2013meanfluxryle, errorbars = t2013sefluxryle)

val <- select(temporal_valley_flux,year, t2013meanfluxvalley, t2013sefluxvalley, location) %>%
          gather(key = "stat", value = flux, -year, -location) %>%
          spread(stat, flux) %>%
          rename(meanflux = t2013meanfluxvalley, errorbars = t2013sefluxvalley)

spatiotemporal_flux <- rbind(ryl, val)


# Figure 5 ----------------------------------------------------------------

plot_spatiotemporal_flux <- ggplot(spatiotemporal_flux, aes(x = year, width = 0.1)) +
          geom_point(aes(y = meanflux, color = location)) +
          geom_errorbar(aes(ymin = meanflux - errorbars, ymax = meanflux + errorbars, color = location), width = 0.2) +
          geom_line(aes(y = meanflux, color = location, group = location)) +
          theme_pubr(base_size = 10, base_family = "") +
          theme(legend.title=element_blank(),
                legend.justification = c(1, 1), 
                legend.position = c(1, 1),
                legend.spacing.x = unit(0.2, "cm"),
                legend.key.size =  unit(0.25, "cm"),
                legend.margin = margin(2, 2, 2, 2)) +
          scale_x_continuous(name = "Year", breaks = seq(2006, 2019, by = 1)) +
          scale_color_manual(values = c("black", "#A5170E"), labels = c("Rylekærene", "Valley floor")) +
          scale_shape_manual(values = c(1,16)) +
          scale_y_continuous(expression(Calculated~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"})),
                             breaks = seq(-1,6.5,0.5), limits = c(0, 4))

plot_spatiotemporal_flux

ggsave(plot_spatiotemporal_flux,
       filename = "figures/fig05.png", 
       bg = "white",
       units = "cm", 
       width = 18, 
       height = 12, 
       pointsize = 8, 
       dpi = 300, 
       device = "png")


# Tidy up environment
rm(list = ls(all.names = TRUE)) 