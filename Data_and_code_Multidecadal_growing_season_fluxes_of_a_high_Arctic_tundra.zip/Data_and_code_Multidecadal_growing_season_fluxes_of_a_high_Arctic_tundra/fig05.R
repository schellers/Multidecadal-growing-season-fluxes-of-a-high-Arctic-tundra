# Methane in Zackenberg Valley, NE Greenland: Multidecadal growing season fluxes of a high Arctic tundra (2021)
# Author: J. H. Scheller, Department of Bioscience, Arctic Research Centre Aarhus University, Roskilde, Denmark & Arctic Geology Department, The University Centre in Svalbard, Longyearbyen, Norway

# Libraries ---------------------------------------------------------------

library(tidyverse)
library(lubridate)
library(readxl)
library(cowplot)
library(tidyr)
library(Cairo)
library(scales)
library(forcats)
library(ggpubr)
library(readr)

# Data -------------------------------------------------------------------

gully_flux <- read_csv("data/gully_surface_fluxes.csv")

# Data preparation --------------------------------------------------------

i <- c(2:8, 11:13, 16:23)

gully_flux[,i] <- apply(gully_flux[,i], 2, function(x) as.numeric(as.character(x))) # vector containing index numbers for columns in the data frame that require conversion from the character to number format


gully_flux2 <- gully_flux %>% # create a new data frame based on the imported data
          mutate(Location = str_replace(Location, "Edge", "Gully")) %>% # rename
          mutate(Location = str_replace(Location, "Surface", "Grasslands")) 

gully_fluxes <- gully_flux2 %>%
          group_by(name) %>%
          mutate(plotmean = mean(CH4_Flux_m)) %>% # first average on each plot...
          ungroup() %>%
          group_by(Location) %>%
          mutate(classmeans = mean(plotmean)) %>% # ...then average the plot means as class means
          mutate(se = sd(plotmean, na.rm = TRUE)/sqrt(sum(!is.na(plotmean)))) # calculate se
          
gully_fluxes$Location <- factor(gully_fluxes$Location, levels = c("Fens", "Grasslands", "Gully"))

          f_labels <- data.frame(Location = c("Fens","Grasslands", "Gully"), label = c("3.83 \u00B1 0.76 (n = 15)", "\u20130.06 \u00B1 0.01 (n = 56)", "0.05 \u00B1 0.02 (n = 31)"))         
          f_labels$Location <- factor(f_labels$Location, levels = c("Fens", "Grasslands", "Gully"))
          
                    
          fig05 <- ggplot(gully_fluxes, aes(Location, CH4_Flux_m)) +
                    geom_boxplot(aes(fill = Location, color = Location), outlier.shape = NA, alpha = 0.1, width = 0.5, size = 1) +
                    geom_jitter(aes(color = Location), alpha = 0.7, width = 0.25) +
                    facet_wrap(.~Location, nrow = 3, scales = 'free', strip.position = "right") +
                    xlab("") +
                    theme_pubr() +
                    scale_color_manual(values = c("#196580", "#4eb265", "#882E72")) + 
                    scale_fill_manual(values = c("#196580", "#4eb265", "#882E72")) + 
                    scale_y_continuous(expand = c(0.15,0) ,expression(Measured~CH[4]~flux~(mg~CH[4]~m^{"\u20132"}~h^{"\u20131"}))) +
                    geom_hline(yintercept = 0, lty = "dashed") +
                    theme(legend.title = element_blank(),
                          legend.justification = c(1, 1), 
                          axis.text.x = element_blank(),
                          axis.ticks.x = element_blank(),
                          legend.position = "none",
                          legend.spacing = unit(0.5, "cm"),
                          legend.background = element_blank(),
                          legend.key.size =  unit(0.5, "cm"),
                          legend.margin = margin(2,2, 2, 2)) +
                    guides(colour = guide_legend(order = 1, ncol =1),
                           fill = guide_legend(order = 1),
                           linetype = guide_legend(order = 2),
                           shape = guide_legend(order = 2)) +
                    geom_text(x = 1, y = Inf, aes(label = label), data = f_labels, vjust=1.5)
          
          fig05
          
          # The boxplots are added to the left of an annotated overview photo of the site to create fig05 as it appears in the manuscript
          # Executing the part below will delete the customized plot in the figures folder.
          
          
# ggsave(fig05,
# filename = "figures/fig05.png", 
# bg = "white",
# units = "cm", 
# width = 8, 
# height = 18, 
# pointsize = 2, 
# dpi = 400, 
# device = "png")          
          